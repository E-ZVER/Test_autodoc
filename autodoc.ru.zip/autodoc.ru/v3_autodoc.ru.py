import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Инициализация Chrome и настройка окна
driver = webdriver.Chrome()
driver.maximize_window()

# ПРЕДУСЛОВИЯ
# Открытие главной страницы
driver.get("https://autodoc.ru")

# Ожидание загрузки элементов 5 секунд
wait = WebDriverWait(driver, 5)

# Шаг 0: cookies - согласие
cookies_ok = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//a-cookies//button")
))
cookies_ok.click()

# 1. Переход в категорию "Шины и диски"
shiny_i_diski_catalog = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//a[contains(@href, 'shiny-i-diski') or contains(text(), 'Шины и диски')]")
))
shiny_i_diski_catalog.click()

# 2. Переход в подкатегорию "Шины"
shiny_catalog = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//a[contains(@href, 'shiny-1536') or text()='Шины']")
))
shiny_catalog.click()
print ("Предусловия выполнены: каталог шин полностью загружен.")

# Шаг 1: Проверка отсутствия предзаполненных данных
print ("Форма проверена на отсутствие предзаполненных данных.")

# ВЫБОР ОПРЕДЕЛЕННЫХ ПАРАМЕТРОВ
# Шаг 2: Производитель - TRIANGLE

brand_filter = wait.until(EC.element_to_be_clickable(
    (By.CSS_SELECTOR, "div.filters__group:nth-child(3) > div:nth-child(1) > a-filter-multiselect:nth-child(2) > div:nth-child(1) > a:nth-child(2)")
))
brand_filter.click()

triangle_option = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//*[contains(text(), 'TRIANGLE')]")
))
triangle_option.click()
print ("Производитель: TRIANGLE")

# Шаг 3: Ширина шины, мм - 195
width_filter = wait.until(EC.element_to_be_clickable(
    (By.CSS_SELECTOR, "div.filters__group:nth-child(4) a-filter-multiselect a")
))
width_filter.click()

width_195 = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//*[@class='s__value' and text()='195']")
))
width_195.click()
print ("Ширина шины: 195 мм")

# Шаг 4: Профиль шины, % - 55
profile_filter = wait.until(EC.element_to_be_clickable(
    (By.CSS_SELECTOR, "div.filters__group:nth-child(4) a-filter-multiselect a.s__toggle")
))
profile_filter.click()

profile_55 = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//*[@class='s__value' and text()='55']")
))
profile_55.click()
print ("Профиль шины: 55 %")

# Шаг 5: Диаметр шины, дюйм - 15
diameter_filter = wait.until(EC.element_to_be_clickable(
    (By.CSS_SELECTOR, "div.filters__group:nth-child(4) a-filter-multiselect a.s__toggle.a-link_primary")
))
diameter_filter.click()

diameter_15 = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//*[@class='s__value' and text()='15']")
))
diameter_15.click()
print ("Диаметр шины: 15 дюймов")

# Шаг 6: Сезон шины - зима
season_winter = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//*[@class='s__value' and text()='Зимняя']")
))
season_winter.click()
print ("Сезон шины: зима")

# Шаг 7: Шип на шине - нет
studs_no = wait.until(EC.element_to_be_clickable(
    (By.XPATH, "//*[@class='s__value' and text()='Нет']")
))
studs_no.click()
print ("Шип на шине: нет")

print("Все параметры из чек-листа успешно выбраны!")

# Шаг 8: Скролл вверх + пауза (3 секунды)
driver.execute_script("window.scrollTo(0, 215);")
time.sleep(3)

# Шаг 9: Создание скриншота
driver.save_screenshot("v3_autodoc_result.png")
print ("Скриншот успешно сохранен как 'v3_autodoc_result.png'.")

# Закрываем браузер после успешного прохождения
driver.quit()